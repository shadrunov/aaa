# Connect Four Bot

The Connect Four bot is a Zulip bot that will allow users
to play a game of Connect Four against either another user,
or the computer.
