Simple Zulip bot that will respond to any query with a "beep boop".

The helloworld bot is a boilerplate bot that can be used as a
template for more sophisticated/evolved Zulip bots.
